package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Streamix BD Dark Glassmorphism Palette
val MidnightBlack = Color(0xFF070913)
val DarkNavyBg = Color(0xFF0D1022)
val DeepIndigoBg = Color(0xFF141833)

// Glass Surfaces
val GlassSurfaceDark = Color(0xB8131833)
val GlassSurfaceLight = Color(0x33FFFFFF)
val GlassCardBg = Color(0x99181D3D)
val GlassCardBorder = Color(0x2E8B9CF7)
val GlassCardBorderHover = Color(0x6600E5FF)

// Accents
val NeonCyan = Color(0xFF00E5FF)
val CyanAccent = Color(0xFF06B6D4)
val VibrantPurple = Color(0xFFA855F7)
val PurpleAccent = Color(0xFF8B5CF6)
val ElectricMagenta = Color(0xFFD946EF)
val CoralRed = Color(0xFFFF3366)
val EmeraldGreen = Color(0xFF10B981)
val AmberRating = Color(0xFFF59E0B)

// Neutrals
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Gradients
val PurpleCyanGradient = Brush.linearGradient(
    colors = listOf(VibrantPurple, NeonCyan)
)

val HeroScrimGradient = Brush.verticalGradient(
    colors = listOf(
        Color.Transparent,
        Color(0x80070913),
        Color(0xEE070913),
        MidnightBlack
    )
)

val GlassBorderGradient = Brush.linearGradient(
    colors = listOf(
        Color.White.copy(alpha = 0.25f),
        Color(0x338B5CF6),
        Color(0x4400E5FF),
        Color.White.copy(alpha = 0.05f)
    )
)

