package com.example.ui.screens.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.StreamixRepository
import com.example.ui.components.GlassButton
import com.example.ui.components.GlassCard
import com.example.ui.components.GlassTextField
import com.example.ui.theme.DeepIndigoBg
import com.example.ui.theme.MidnightBlack
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.PurpleCyanGradient
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VibrantPurple
import kotlinx.coroutines.launch

@Composable
fun AdminLoginScreen(
    repository: StreamixRepository,
    onAdminLoginSuccess: () -> Unit,
    onBackToUserApp: () -> Unit,
    modifier: Modifier = Modifier
) {
    var adminUsername by remember { mutableStateOf("") }
    var adminPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBlack)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 440.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(PurpleCyanGradient),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AdminPanelSettings,
                    contentDescription = "Admin Panel",
                    tint = MidnightBlack,
                    modifier = Modifier.size(36.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text("👑 ADMIN PANEL", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text("Streamix BD Dedicated Administration Portal", color = VibrantPurple, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(24.dp))

            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = DeepIndigoBg,
                borderColor = VibrantPurple.copy(alpha = 0.6f)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("Admin Authentication", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("Only authorized administrator accounts can continue.", color = TextSecondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(18.dp))

                    GlassTextField(
                        value = adminUsername,
                        onValueChange = { adminUsername = it; errorMessage = null },
                        label = "Admin Username / Email",
                        placeholder = "Enter admin username or email",
                        leadingIcon = Icons.Default.Person,
                        testTag = "admin_login_username"
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    GlassTextField(
                        value = adminPassword,
                        onValueChange = { adminPassword = it; errorMessage = null },
                        label = "Admin Password",
                        placeholder = "Enter admin password",
                        leadingIcon = Icons.Default.Lock,
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle password visibility",
                                    tint = NeonCyan
                                )
                            }
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        isPassword = !passwordVisible,
                        testTag = "admin_login_password"
                    )

                    errorMessage?.let {
                        Text(it, color = Color(0xFFFF6B6B), fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                    }
                    Spacer(modifier = Modifier.height(18.dp))

                    if (isLoading) {
                        Box(Modifier.fillMaxWidth().height(48.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = NeonCyan, modifier = Modifier.size(28.dp))
                        }
                    } else {
                        GlassButton(
                            text = "Login to Admin Dashboard",
                            icon = Icons.Default.AdminPanelSettings,
                            onClick = {
                                if (adminUsername.isBlank() || adminPassword.isBlank()) {
                                    errorMessage = "Please enter admin username/email and password"
                                    return@GlassButton
                                }
                                isLoading = true
                                scope.launch {
                                    val result = repository.adminLogin(adminUsername, adminPassword)
                                    isLoading = false
                                    if (result.isSuccess) onAdminLoginSuccess()
                                    else errorMessage = "Invalid admin credentials"
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "admin_submit_btn"
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text("Admin registration is disabled.", color = TextMuted, fontSize = 11.sp)

            Spacer(modifier = Modifier.height(8.dp))
            TextButton(onClick = onBackToUserApp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Return to User Streamix BD", color = NeonCyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text("© Streamix BD Official • CMS v10.0.1", color = TextMuted, fontSize = 11.sp)
        }
    }
}
