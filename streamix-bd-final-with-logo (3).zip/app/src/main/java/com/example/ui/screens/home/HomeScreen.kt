package com.example.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.PostAdd
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Category
import com.example.data.model.ContentItem
import com.example.data.model.WatchHistory
import com.example.data.repository.StreamixRepository
import com.example.ui.components.CategoryPillRow
import com.example.ui.components.ContinueWatchingRow
import com.example.ui.components.GlassCard
import com.example.ui.components.HeroBanner
import com.example.ui.components.HorizontalContentRow
import com.example.ui.components.StreamixFooter
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.DeepIndigoBg
import com.example.ui.theme.GlassCardBorder
import com.example.ui.theme.GlassSurfaceDark
import com.example.ui.theme.MidnightBlack
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.PurpleCyanGradient
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VibrantPurple
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    repository: StreamixRepository,
    onContentClick: (ContentItem) -> Unit,
    onWatchClick: (ContentItem) -> Unit,
    onNavigateToCategory: (String) -> Unit,
    onNavigateToRequest: () -> Unit,
    modifier: Modifier = Modifier
) {
    val allContent by repository.getAllPublishedContent().collectAsStateWithLifecycle(emptyList())
    val categories by repository.getCategories().collectAsStateWithLifecycle(emptyList())
    val continueWatchingList by repository.getContinueWatchingList().collectAsStateWithLifecycle(emptyList())
    val scope = rememberCoroutineScope()

    var selectedCategorySlug by remember { mutableStateOf("all") }

    val featuredItem = allContent.firstOrNull { it.isFeatured } ?: allContent.firstOrNull()
    val isFeaturedSaved by repository.isContentSaved(featuredItem?.id ?: "").collectAsStateWithLifecycle(false)

    val filteredContent = if (selectedCategorySlug == "all") {
        allContent
    } else {
        allContent.filter { it.categorySlug == selectedCategorySlug || it.type.equals(selectedCategorySlug, ignoreCase = true) }
    }

    val trendingItems = filteredContent.filter { it.isTrending }
    val natokItems = filteredContent.filter { it.type == "NATOK" }
    val filmItems = filteredContent.filter { it.type == "FILM" || it.type == "MOVIE" }
    val seriesItems = filteredContent.filter { it.type == "SERIES" }
    val topRatedItems = filteredContent.filter { it.rating >= 4.7 }.sortedByDescending { it.rating }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBlack)
    ) {
        if (allContent.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = NeonCyan)
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .testTag("home_screen_scroll")
            ) {
                // Hero Banner
                if (featuredItem != null && selectedCategorySlug == "all") {
                    HeroBanner(
                        item = featuredItem,
                        onWatchClick = { onWatchClick(featuredItem) },
                        onDetailsClick = { onContentClick(featuredItem) },
                        onMyListToggle = {
                            scope.launch { repository.toggleSaveContent(featuredItem.id) }
                        },
                        isSaved = isFeaturedSaved
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Categories Row
                CategoryPillRow(
                    categories = categories,
                    selectedCategorySlug = selectedCategorySlug,
                    onSelectCategory = { selectedCategorySlug = it }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Continue Watching
                if (continueWatchingList.isNotEmpty() && selectedCategorySlug == "all") {
                    ContinueWatchingRow(
                        items = continueWatchingList,
                        onItemClick = { content, _ -> onWatchClick(content) }
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                }

                // Trending Now
                HorizontalContentRow(
                    title = if (selectedCategorySlug == "all") "Trending Now in BD" else "Trending Selection",
                    items = trendingItems.ifEmpty { filteredContent.take(5) },
                    onItemClick = onContentClick,
                    onSeeAllClick = { onNavigateToCategory(selectedCategorySlug) }
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Bangla Natok
                if (natokItems.isNotEmpty()) {
                    HorizontalContentRow(
                        title = "Bangla Natok & Eid Specials",
                        items = natokItems,
                        onItemClick = onContentClick,
                        onSeeAllClick = { onNavigateToCategory("natok") }
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                }

                // Films & Blockbusters
                if (filmItems.isNotEmpty()) {
                    HorizontalContentRow(
                        title = "Blockbuster Films & Cinema",
                        items = filmItems,
                        onItemClick = onContentClick,
                        onSeeAllClick = { onNavigateToCategory("films") }
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                }

                // Original Series
                if (seriesItems.isNotEmpty()) {
                    HorizontalContentRow(
                        title = "Original Thriller & Drama Series",
                        items = seriesItems,
                        onItemClick = onContentClick,
                        onSeeAllClick = { onNavigateToCategory("series") }
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                }

                // Top Rated
                if (topRatedItems.isNotEmpty()) {
                    HorizontalContentRow(
                        title = "Critically Acclaimed (4.7+ ★)",
                        items = topRatedItems,
                        onItemClick = onContentClick
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                }

                // Content Request Callout Card
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    backgroundColor = DeepIndigoBg,
                    borderColor = VibrantPurple.copy(alpha = 0.5f),
                    onClick = onNavigateToRequest
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(PurpleCyanGradient),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PostAdd,
                                    contentDescription = null,
                                    tint = MidnightBlack,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Text(
                                    text = "Missing your favorite Natok or Film?",
                                    color = TextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Submit a title request to the Streamix team",
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Request Content",
                            tint = NeonCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // Streamix Footer
                StreamixFooter()

                Spacer(modifier = Modifier.height(60.dp))
            }
        }
    }
}
