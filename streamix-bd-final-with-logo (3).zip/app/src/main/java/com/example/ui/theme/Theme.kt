package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val StreamixDarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = MidnightBlack,
    primaryContainer = VibrantPurple.copy(alpha = 0.25f),
    onPrimaryContainer = NeonCyan,
    secondary = VibrantPurple,
    onSecondary = Color.White,
    secondaryContainer = DeepIndigoBg,
    onSecondaryContainer = TextPrimary,
    tertiary = ElectricMagenta,
    onTertiary = Color.White,
    background = MidnightBlack,
    onBackground = TextPrimary,
    surface = DarkNavyBg,
    onSurface = TextPrimary,
    surfaceVariant = DeepIndigoBg,
    onSurfaceVariant = TextSecondary,
    outline = GlassCardBorder,
    outlineVariant = GlassCardBorderHover,
    error = CoralRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    // Streamix BD is designed as a unified premium midnight glassmorphism experience
    MaterialTheme(
        colorScheme = StreamixDarkColorScheme,
        typography = Typography,
        content = content
    )
}

