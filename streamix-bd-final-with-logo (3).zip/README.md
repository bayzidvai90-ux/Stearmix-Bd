# Streamix BD v10.0.1

Android Kotlin/Compose project.

## Build

- Debug APK: `gradle :app:assembleDebug`
- GitHub Actions workflow: `.github/workflows/build-apk.yml`

## Admin

Admin registration is disabled. A local development admin is seeded only when `STREAMIX_ADMIN_PASSWORD` is supplied at build time. This is a local/demo authentication mechanism backed by Room, not production server-side authorization. For production, use a real backend authentication service and enforce admin authorization on the server.
